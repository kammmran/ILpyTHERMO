from .core import DataFetcher, DataProcessor
from .utils import standardize_headers, deduplicate_columns

__version__ = "0.1.0"
